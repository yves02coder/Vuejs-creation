const exercice0 = require('./exercice-0');

test('retourne Coding Dojo', () => {
  expect(exercice0()).toBe("Coding Dojo");
});

