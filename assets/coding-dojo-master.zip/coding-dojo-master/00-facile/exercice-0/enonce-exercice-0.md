# Exercice 0

L'objectif de cet exercice est de vous familiariser avec l'environnement du Coding Dojo.

Vous devez créer une fonction qui renvoie `Coding Dojo` (utilisez le mot-clé `return`).