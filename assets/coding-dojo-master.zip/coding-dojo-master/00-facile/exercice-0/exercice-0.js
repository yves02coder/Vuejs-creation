function exercice0() {
  
}

// Ne touchez pas à la ligne suivante
module.exports = exercice0;