# Exercice 6

## FizzBuzz

Rédigez une fonction qui retourne, sous la forme d'une chaîne de caractères, les nombres de 1 à 200 dans l’ordre, en remplaçant :

* les multiples de 3 par le mot Fizz
* les multiples de 5 par le mot Buzz
* les multiples de 15 par le mot FizzBuzz

Les différents mots devront être séparés par des " - ".

Attention, l'exercice n'est pas si simple qu'il n'y paraît...

## Exemple

Voici un extrait pour les nombres de 1 à 10 :
'1 - 2 - Fizz - 4 - Buzz - Fizz - 7 - 8 - Fizz - Buzz' 