function exercice6() {

}


// Ne touchez pas à la ligne suivante
module.exports = exercice6;