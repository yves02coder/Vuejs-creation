# Exercice 1

L'objectif de cet exercice est de créer une fonction permettant de renvoyer le **mot** correspondant au chiffre passé en argument.

Les valeurs d'entrées sont les chiffres de `0` à `2` inclu.

## Exemples
- Pour le chiffre `0`, la fonction doit renvoyer `zéro`
- Pour le chiffre `1`, la fonction doit renvoyer `un`
- Pour le chiffre `2`, la fonction doit renvoyer `deux`