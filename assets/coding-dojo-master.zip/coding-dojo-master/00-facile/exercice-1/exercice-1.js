function exercice1(chiffre) {
  
}

// Ne touchez pas à la ligne suivante
module.exports = exercice1;