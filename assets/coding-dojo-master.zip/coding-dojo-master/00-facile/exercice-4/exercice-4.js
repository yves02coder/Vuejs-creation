function exercice4(nombre) {
  
}

// Ne touchez pas à la ligne suivante
module.exports = exercice4;