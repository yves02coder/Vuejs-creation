function exercice5(cote1, cote2, cote3) {
  
}

// Ne touchez pas à la ligne suivante
module.exports = exercice5;