function exercice3(n) {
  
}

function nombreEstPair(nombre) {
  // On verra l'opérateur modulo '%' dans le module intermédiaire !
  return nombre % 2 === 0;
}

// Ne touchez pas à la ligne suivante
module.exports = exercice3;