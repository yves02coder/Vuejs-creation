function exercice5(tableau) {

}

// Ne touchez pas à la ligne suivante
module.exports = exercice5;
