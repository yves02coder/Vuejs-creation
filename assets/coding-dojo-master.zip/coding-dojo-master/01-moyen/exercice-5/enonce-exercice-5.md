# Exercice 5

Étant donné un tableau d'entiers `tableau`, la fonction doit renvoyer la somme de ses éléments.

## Exemples
- Pour le tableau `[1, 2, 3, 4]`, la fonction doit renvoyer `10` car 1 + 2 + 3 + 4 = 10
- Pour le tableau `[1, 2, 3, 4, 10, 11]`, la fonction doit renvoyer `31` car 1 + 2 + 3 + 4 + 10 + 11 = 31