function exercice7(phrase, decalage) {

}

// Ne touchez pas à la ligne suivante
module.exports = exercice7;