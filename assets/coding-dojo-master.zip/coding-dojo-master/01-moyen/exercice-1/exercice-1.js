function exercice1(mot, liste) {
  
}

// Ne touchez pas à la ligne suivante
module.exports = exercice1;