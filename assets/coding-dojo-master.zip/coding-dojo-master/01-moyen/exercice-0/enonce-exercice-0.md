# Exercice 0

Convertissez une phrase donnée en son acronyme.

## Exemples
- Pour la phrase `JavaScript est vraiment top`, ça doit renvoyer `JEVT`
- Pour la phrase `toute une phrase en minuscule`, ça doit renvoyer `TUPEM`
- Pour la phrase `TU PEUX AUSSI TOUT ECRIRE EN MAJUSCULE`, ça doit renvoyer `TPATEEM`
- Pour la phrase `On PeUT AusSi MixEr LeS DEUx`, ça doit renvoyer `OPAMLD`
- Pour la phrase `Dépêche toi j'ai rendez-vous`, ça doit renvoyer `DTJR`
- Pour la phrase `Les "guillemets" vont faire planter ton code`, ça doit renvoyer `LGVFPTC`