function exercice0(phrase) {
  
}

// Ne touchez pas à la ligne suivante
module.exports = exercice0;