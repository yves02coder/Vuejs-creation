# Exercices moyens 🤔

Vous saurez faire tous les exercices moyens si vous avez suivi le **module intermédiaire** de ma formation [JavaScript de Zéro](https://www.javascriptdezero.com).

# Comment faire un exercice ?

Lisez le fichier [LISEZMOI.md](../00-facile/LISEZMOI.md) du dossier `00-facile`.

# Comment déboguer un exercice ?

Lisez le fichier [LISEZMOI.md](../00-facile/LISEZMOI.md) du dossier `00-facile`.

# ❤️ Vous aimez le CodingDojo ?

Aidez-moi à le faire connaître [en partageant ce tweet](https://twitter.com/intent/tweet?text=D%C3%A9couvrez%20l%27excellent%20%28et%20gratuit%20%21%29%20Coding%20Dojo%20de%20la%20formation%20JavaScript%20de%20Z%C3%A9ro%20et%20entra%C3%AEnez-vous%20%C3%A0%20d%C3%A9velopper%20en%20JavaScript%20avec%20des%20exercices%20en%20Fran%C3%A7ais%20directement%20depuis%20VSCode.&url=https%3A%2F%2Fgithub.com%2Fjavascriptdezero%2Fcoding-dojo&via=JeremyMouzin&related=JeremyMouzin&hashtags=JavaScript,CodingDojo).
Beaucoup de temps et d'investissement ont été consacrés à son élaboration.

Merci de votre soutien 😘.