function exercice4(x, y) {
  
}

// Ne touchez pas à la ligne suivante
module.exports = exercice4;